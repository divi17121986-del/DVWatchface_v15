package com.dvwatchfaces.superman.lite;

import android.Manifest;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.Locale;

/**
 * Маска недели (Пн=0 ... Вс=6):
 *  биты 0..6  — праздничные/выходные дни (жёлтые на циферблате),
 *  биты 7..13 — дни рождения (зелёные).
 * Читает системный календарь и календарь Wear (WearableCalendarContract).
 */
public final class HolidayMask {

    public static final class Result {
        public int mask;
        public int holidays;
        public int birthdays;
        public boolean online;   // есть ли данные isdayoff.ru за эту неделю
        public int contactBd;   // всего дней рождения в контактах
        public int total;       // всего событий в окне недели
        public boolean permission;
        public String details = "";
    }

    private static final String[] HOLIDAY_WORDS = {
            "праздник", "выходн", "нерабоч", "holiday", "перенос", "каникул", "отпуск"};
    private static final String[] BIRTHDAY_WORDS = {
            "рожден", "birthday", "д.р.", "днюха", "юбилей"};

    private HolidayMask() {}

    public static Result compute(Context ctx) {
        Result r = new Result();
        r.permission = ctx.checkSelfPermission(Manifest.permission.READ_CALENDAR)
                == PackageManager.PERMISSION_GRANTED;
        if (!r.permission) return r;

        ZoneId zone = ZoneId.systemDefault();
        LocalDate mon = LocalDate.now(zone).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        long monEpochDay = mon.toEpochDay();
        long startMs = mon.minusDays(1).atStartOfDay(zone).toInstant().toEpochMilli();
        long endMs = mon.plusDays(8).atStartOfDay(zone).toInstant().toEpochMilli();

        // 1) системный календарь
        Uri.Builder b = CalendarContract.Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(b, startMs);
        ContentUris.appendId(b, endMs);
        scan(ctx, r, b.build(),
                new String[]{"begin", "end", "title", "allDay", "calendar_displayName"}, monEpochDay, zone, "sys");

        // 2) календарь Wear (Google Calendar на часах)
        String W = "content://com.google.android.wearable.provider.calendar/instances/";
        scan(ctx, r, Uri.parse(W + "when/" + startMs + "/" + endMs),
                new String[]{"begin", "end", "title", "allDay", "calendar_displayName", "deleted"}, monEpochDay, zone, "wear");
        contacts(ctx, r, mon);
        online(ctx, r, mon);
        builtin(r, mon);
        return r;
    }

    private static final String PREFS = "dv_days";
    private static final long CACHE_MS = 3L * 86400000L;

    private static String monthKey(LocalDate d) {
        return String.format(Locale.ROOT, "m%04d-%02d", d.getYear(), d.getMonthValue());
    }

    /**
     * Скачивает производственный календарь РФ (isdayoff.ru, свободный API) на месяцы текущей недели
     * и кэширует. Вызывать только из фонового потока. Строка ответа: по символу на день,
     * 1 = нерабочий, 0 = рабочий, 2 = сокращённый.
     */
    public static void refreshOnline(Context ctx) {
        android.content.SharedPreferences sp = ctx.getSharedPreferences(PREFS, 0);
        LocalDate mon = LocalDate.now(ZoneId.systemDefault())
                .with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate[] months = {mon, mon.plusDays(6)};
        for (int i = 0; i < months.length; i++) {
            LocalDate m = months[i];
            if (i == 1 && monthKey(m).equals(monthKey(months[0]))) break;
            String key = monthKey(m);
            long age = System.currentTimeMillis() - sp.getLong("t" + key, 0);
            if (sp.getString(key, null) != null && age < CACHE_MS) continue;
            java.net.HttpURLConnection c = null;
            try {
                java.net.URL u = new java.net.URL("https://isdayoff.ru/api/getdata?year="
                        + m.getYear() + "&month=" + m.getMonthValue());
                c = (java.net.HttpURLConnection) u.openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(8000);
                if (c.getResponseCode() != 200) continue;
                java.io.BufferedReader br = new java.io.BufferedReader(
                        new java.io.InputStreamReader(c.getInputStream(), "UTF-8"));
                String body = br.readLine();
                if (body == null) continue;
                body = body.trim();
                if (body.length() == m.lengthOfMonth() && body.matches("[0-9]+")) {
                    sp.edit().putString(key, body)
                            .putLong("t" + key, System.currentTimeMillis()).apply();
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
        }
    }

    /** Нерабочие будни из кэша isdayoff.ru. Субботы и воскресенья циферблат красит сам. */
    private static void online(Context ctx, Result r, LocalDate mon) {
        android.content.SharedPreferences sp = ctx.getSharedPreferences(PREFS, 0);
        int have = 0;
        for (int k = 0; k < 7; k++) {
            LocalDate day = mon.plusDays(k);
            String s = sp.getString(monthKey(day), null);
            if (s == null || day.getDayOfMonth() > s.length()) continue;
            have++;
            boolean weekday = day.getDayOfWeek().getValue() <= 5;
            if (weekday && s.charAt(day.getDayOfMonth() - 1) == '1'
                    && (r.mask & (1 << k)) == 0) {
                r.mask |= 1 << k;
                r.holidays++;
                r.details += "Вых " + dow(k) + ": (isdayoff.ru)\n";
            }
        }
        r.online = have > 0;
    }

    /**
     * Встроенный список нерабочих праздничных дней РФ (2026–2027, с учётом переносов)
     * и личных выходных. Не зависит от синхронизации календаря.
     * Формат: "ГГГГ-ММ-ДД". Чтобы добавить свой день — допишите строку и пересоберите.
     */
    private static final String[] BUILTIN_DAYS = {
            // 2026
            "2026-01-01", "2026-01-02", "2026-01-03", "2026-01-04", "2026-01-05", "2026-01-06",
            "2026-01-07", "2026-01-08", "2026-01-09",
            "2026-02-23", "2026-03-08", "2026-03-09",
            "2026-05-01", "2026-05-09", "2026-05-11",
            "2026-06-12", "2026-11-04", "2026-12-31",
            // 2027
            "2027-01-01", "2027-01-02", "2027-01-03", "2027-01-04", "2027-01-05", "2027-01-06",
            "2027-01-07", "2027-01-08",
            "2027-02-22", "2027-02-23", "2027-03-08",
            "2027-05-01", "2027-05-03", "2027-05-09", "2027-05-10",
            "2027-06-12", "2027-06-14", "2027-11-04", "2027-11-05", "2027-12-31"
    };

    private static void builtin(Result r, LocalDate mon) {
        for (String d : BUILTIN_DAYS) {
            long k = LocalDate.parse(d).toEpochDay() - mon.toEpochDay();
            if (k >= 0 && k <= 6 && (r.mask & (1 << (int) k)) == 0) {
                r.mask |= 1 << (int) k;
                r.holidays++;
                r.details += "Вых " + dow((int) k) + ": (встроенный список)\n";
            }
        }
    }

    /** Дни рождения из контактов (ContactsContract, тип события «день рождения»). */
    private static void contacts(Context ctx, Result r, LocalDate mon) {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            r.details += "нет доступа к контактам\n";
            return;
        }
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                "(?:(\\d{4})|-)-(\\d{1,2})-(\\d{1,2})");
        try (Cursor c = ctx.getContentResolver().query(
                android.provider.ContactsContract.Data.CONTENT_URI,
                new String[]{android.provider.ContactsContract.Data.DISPLAY_NAME,
                        android.provider.ContactsContract.CommonDataKinds.Event.START_DATE},
                android.provider.ContactsContract.Data.MIMETYPE + "=? AND "
                        + android.provider.ContactsContract.CommonDataKinds.Event.TYPE + "=?",
                new String[]{android.provider.ContactsContract.CommonDataKinds.Event.CONTENT_ITEM_TYPE,
                        String.valueOf(android.provider.ContactsContract.CommonDataKinds.Event.TYPE_BIRTHDAY)},
                null)) {
            if (c == null) return;
            while (c.moveToNext()) {
                r.contactBd++;
                String d = c.getString(1);
                r.details += "контакт: " + c.getString(0) + " " + d + "\n";
                if (d == null) continue;
                java.util.regex.Matcher m = p.matcher(d.trim());
                if (!m.matches()) continue;
                int mo = Integer.parseInt(m.group(2)), da = Integer.parseInt(m.group(3));
                for (int k = 0; k < 7; k++) {
                    LocalDate day = mon.plusDays(k);
                    if (day.getMonthValue() == mo && day.getDayOfMonth() == da) {
                        if ((r.mask & (1 << (k + 7))) == 0) {
                            r.mask |= 1 << (k + 7);
                            r.birthdays++;
                            r.details += "ДР " + dow(k) + ": " + c.getString(0) + " [контакт]\n";
                        }
                    }
                }
            }
        } catch (Exception e) {
            r.details += "contacts: " + e.getClass().getSimpleName() + "\n";
        }
    }

    private static void scan(Context ctx, Result r, Uri uri, String[] proj,
                             long monEpochDay, ZoneId zone, String tag) {
        try (Cursor c = ctx.getContentResolver().query(uri, proj, null, null, null)) {
            if (c == null) return;
            while (c.moveToNext()) {
                String rawTitle = c.getString(2);
                String title = rawTitle == null ? "" : rawTitle.toLowerCase(Locale.ROOT);
                boolean allDay = c.getInt(3) == 1;
                String cal = c.getString(4);
                cal = cal == null ? "" : cal.toLowerCase(Locale.ROOT);
                boolean holCal = cal.contains("праздник") || cal.contains("holiday");
                long begin = c.getLong(0), end = c.getLong(1);
                if (proj.length > 5 && c.getInt(5) == 1) continue; // удалённые записи Wear
                r.total++;
                boolean bd = hasAny(title, BIRTHDAY_WORDS);
                if (bd && "wear".equals(tag)) continue; // календарь Wear хранит удалённые ДР, берём только контакты
                boolean hol = !bd && allDay && (holCal || hasAny(title, HOLIDAY_WORDS));
                if (!bd && !hol) continue;
                long first, last;
                if (allDay) { // сутки по UTC
                    first = Math.floorDiv(begin, 86400000L);
                    last = Math.floorDiv(end - 1, 86400000L);
                } else {      // по местному времени
                    first = java.time.Instant.ofEpochMilli(begin).atZone(zone).toLocalDate().toEpochDay();
                    last = java.time.Instant.ofEpochMilli(Math.max(begin, end - 1))
                            .atZone(zone).toLocalDate().toEpochDay();
                }
                for (long d = first; d <= last; d++) {
                    long k = d - monEpochDay;
                    if (k < 0 || k > 6) continue;
                    int bit = (int) k + (bd ? 7 : 0);
                    if ((r.mask & (1 << bit)) == 0) {
                        r.mask |= 1 << bit;
                        if (bd) r.birthdays++; else r.holidays++;
                        r.details += (bd ? "ДР " : "Вых ") + dow((int) k) + ": " + rawTitle + " [" + tag + "]\n";
                    }
                }
            }
        } catch (Exception e) {
            r.details += tag + ": " + e.getClass().getSimpleName() + "\n";
        }
    }

    /** Подробная диагностика: сколько строк и какие названия отдаёт каждый источник за ±45 дней. */
    public static String diag(Context ctx) {
        StringBuilder sb = new StringBuilder();
        long now = System.currentTimeMillis();
        long a = now - 45L * 86400000L, b = now + 45L * 86400000L;
        long ja = Math.floorDiv(a, 86400000L) + 2440588L, jb = Math.floorDiv(b, 86400000L) + 2440588L;
        String W = "content://com.google.android.wearable.provider.calendar/";
        String[][] src = {
                {"sys", CalendarContract.Instances.CONTENT_URI + "/" + a + "/" + b},
                {"wear", W + "instances/when/" + a + "/" + b},
                {"wday", W + "instances/whenbyday/" + ja + "/" + jb},
                {"wevt", W + "events"},
        };
        for (String[] s : src) {
            try (Cursor c = ctx.getContentResolver().query(Uri.parse(s[1]), null, null, null, null)) {
                if (c == null) { sb.append(s[0]).append(": null\n"); continue; }
                sb.append(s[0]).append(": ").append(c.getCount()).append(" стр\n");
                int ti = c.getColumnIndex("title"), ad = c.getColumnIndex("allDay");
                int bi = c.getColumnIndex("begin");
                if (bi < 0) bi = c.getColumnIndex("dtstart");
                int di = c.getColumnIndex("deleted");
                int n = 0;
                while (c.moveToNext() && n++ < 8) {
                    String when = "";
                    if (bi >= 0) {
                        when = java.time.Instant.ofEpochMilli(c.getLong(bi))
                                .atZone(java.time.ZoneOffset.UTC).toLocalDate().toString();
                    }
                    sb.append("  ").append(ti >= 0 ? c.getString(ti) : "?")
                      .append(ad >= 0 ? " [" + c.getInt(ad) + "]" : "")
                      .append(' ').append(when)
                      .append(di >= 0 ? " del=" + c.getInt(di) : "").append('\n');
                }

                if (c.getCount() > 0 && c.moveToFirst() == false) { }
            } catch (Exception e) {
                sb.append(s[0]).append(": ").append(e.getClass().getSimpleName())
                  .append(' ').append(String.valueOf(e.getMessage()).replace('\n', ' ')).append('\n');
            }
        }
        return sb.toString();
    }

    static String dow(int k) {
        return new String[]{"Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"}[k];
    }

    private static boolean hasAny(String s, String[] words) {
        for (String w : words) if (s.contains(w)) return true;
        return false;
    }
}
